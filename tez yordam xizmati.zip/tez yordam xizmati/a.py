from flask import Flask, render_template, request, redirect, url_for, flash

app = Flask(__name__)
app.secret_key = "emergency_secret_key"

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/emergency', methods=['GET', 'POST'])
def emergency():
    if request.method == 'POST':
        name = request.form['name']
        room = request.form['room']
        issue = request.form['issue']
        print(f"Tez Yordam So‘rovi: {name}, Xona: {room}, Muammo: {issue}")
        flash("So‘rov qabul qilindi! Tez yordam yo‘lda.", "success")
        return redirect(url_for('index'))
    return render_template('emergency.html')

if __name__ == '__main__':
    app.run(debug=True)